package com.blood.model;

public class UserAccount {
	
	private String username;
	private String password;
	private String role;
	private String contact; 
    private String address ;
    private String city;
    private String state;
    private String pincode;
    private String email;
    private String bloodgroup;

	public UserAccount() {
		// TODO Auto-generated constructor stub
	}

	public UserAccount(String username, String password, String role,
			String contact, String address, String city, String state,
			String pincode, String email, String bloodgroup) {
		super();
		this.username = username;
		this.password = password;
		this.role = role;
		this.contact = contact;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.email = email;
		this.bloodgroup = bloodgroup;
	}

	public String getUserName() {
		return username;
	}

	public void setUserName(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBloodgroup() {
		return bloodgroup;
	}

	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}

	
	
	
	
}