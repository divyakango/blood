package com.blood.model;

public class DonorForm {
	private String username;
	private String contact;
	private String location;
	private String donationdate;
	private String bloodgroup;
	private String quantity;
	public DonorForm() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DonorForm(String username, String contact, String location,
			String donationdate, String bloodgroup, String quantity) {
		super();
		this.username = username;
		this.contact = contact;
		this.location = location;
		this.donationdate = donationdate;
		this.bloodgroup = bloodgroup;
		this.quantity = quantity;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getDonationdate() {
		return donationdate;
	}
	public void setDonationdate(String donationdate) {
		this.donationdate = donationdate;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodgroup(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	
}
