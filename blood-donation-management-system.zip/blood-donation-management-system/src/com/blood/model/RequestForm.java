package com.blood.model;

public class RequestForm {
	private String username;
	private String patientname;
	private String age;
	private String contact;
	private String hospitalname;
	private String location;
	private String purpose;
	private String requireddate;
	private String bloodgroup;
	private String quantity;
	private String status;
	public RequestForm() {
		super();
		// TODO Auto-generated constructor stub
	}
	public RequestForm(String username, String patientname, String age, String contact,
			String hospitalname, String location, String purpose,
			String requireddate, String bloodgroup, String quantity, String status) {
		super();
		this.username = username;
		this.patientname = patientname;
		this.age = age;
		this.contact = contact;
		this.hospitalname = hospitalname;
		this.location = location;
		this.purpose = purpose;
		this.requireddate = requireddate;
		this.bloodgroup = bloodgroup;
		this.quantity = quantity;
		this.status = status;
	}
	
	public String getusername() {
		return username;
	}
	public void setusername(String username) {
		this.username = username;
	} 
	public String getPatientname() {
		return patientname;
	}
	public void setPatientname(String patientname) {
		this.patientname = patientname;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
	public String getHospitalname() {
		return hospitalname;
	}
	public void setHospitalname(String hospitalname) {
		this.hospitalname = hospitalname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public String getRequireddate() {
		return requireddate;
	}
	public void setRequireddate(String requireddate) {
		this.requireddate = requireddate;
	}
	public String getBloodgroup() {
		return bloodgroup;
	}
	public void setBloodtype(String bloodgroup) {
		this.bloodgroup = bloodgroup;
	}
	public String getquantity() {
		return quantity;
	}
	public void setquantity(String quantity) {
		this.quantity = quantity;
	}
	public String getstatus() {
		return status;
	}
	public void setstatus(String status) {
		this.status = status;
	}
	
	

}
