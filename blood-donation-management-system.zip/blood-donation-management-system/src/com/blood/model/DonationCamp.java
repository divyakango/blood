package com.blood.model;

public class DonationCamp {
	
	private String Theme;
	private String Location;
	private String City;
	private String State;
	private String StartDate;
	private String FinishDate;
	private String Contact;
	private String OrganisedBy;
	public DonationCamp() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DonationCamp(String theme, String location, String city,
			String state, String startDate, String finishDate, String contact,
			String organisedBy) {
		super();
		Theme = theme;
		Location = location;
		City = city;
		State = state;
		StartDate = startDate;
		FinishDate = finishDate;
		Contact = contact;
		OrganisedBy = organisedBy;
	}
	public String getTheme() {
		return Theme;
	}
	public void setTheme(String theme) {
		Theme = theme;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getStartDate() {
		return StartDate;
	}
	public void setStartDate(String startDate) {
		StartDate = startDate;
	}
	public String getFinishDate() {
		return FinishDate;
	}
	public void setFinishDate(String finishDate) {
		FinishDate = finishDate;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	public String getOrganisedBy() {
		return OrganisedBy;
	}
	public void setOrganisedBy(String organisedBy) {
		OrganisedBy = organisedBy;
	}
	
	

}
