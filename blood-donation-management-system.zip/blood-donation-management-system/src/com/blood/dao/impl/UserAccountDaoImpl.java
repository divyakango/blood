package com.blood.dao.impl;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;




import java.util.ArrayList;
import java.util.List;

import com.blood.dao1.UserAccountDao;


import com.blood.model.UserAccount;
import com.blood.utils.ConnectionFactory;
import com.blood.utils.DBUtils;
import com.blood.utils.QueryConstants;

public class UserAccountDaoImpl implements UserAccountDao{

	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatment;

	public UserAccountDaoImpl() {
	}
	
	
	
	public UserAccount getDetail(String userName) throws SQLException {

        String strr = "'"+userName+"'";
        String query = "SELECT * FROM xbbnhnj_login WHERE username ="+strr;
        
        ResultSet rs = null;
        UserAccount account = null;
        
        try {
               connection = ConnectionFactory.getConnection();
               statement = connection.createStatement();
               rs = statement.executeQuery(query);
               
               if(rs.next()) {
               
                     account = new UserAccount();
                     account.setUserName(rs.getString(1));
                     
                     account.setRole(rs.getString(2));
                     account.setContact(rs.getString(3));
                     account.setAddress(rs.getString(4));
                     account.setCity(rs.getString(5));
                     account.setState(rs.getString(6));
                     account.setPincode(rs.getString(7));
                     account.setEmail(rs.getString(8));
                     account.setBloodgroup(rs.getString(9));
                     System.out.println(account);
               }
               

        } finally {
               DBUtils.close(rs);
               DBUtils.close(statement);
               DBUtils.close(connection);
        }
        return account;
 }
 

	
	
	
	
	
	
	
	
	
	@Override
	public UserAccount findUser(String userId, String userPass) {

		ResultSet rs = null;
		UserAccount found = null;

		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement(QueryConstants.SELECT_USER);
			preparedStatment.setString(1, userId);
			preparedStatment.setString(2, userPass);
			rs = preparedStatment.executeQuery();
			if (rs.next()) {
				found = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4), rs.getString(5), rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9),rs.getString(10));
				
			}

		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		return found;
	}
	
	
	
	
	public List<UserAccount> allUsers() throws SQLException {

		
          ResultSet rs=null;
          List<UserAccount> foundList = new ArrayList<UserAccount>();
          UserAccount currentUser = null;
          try {
               connection = ConnectionFactory.getConnection();
               preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER);
           
               rs = preparedStatment.executeQuery();
               while (rs.next()) {
                    currentUser = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10));
                    foundList.add(currentUser);
                    System.out.println(currentUser);
                    //System.out.println("123");
               }
          } catch (SQLException e) {
               System.out.println("SQLException in get() method");
               e.printStackTrace();
          } finally {
               DBUtils.close(rs);
               DBUtils.close(preparedStatment);
               DBUtils.close(connection);
          }
          return foundList;
    }



	
	
	
	
	
	
	
	
	
	
	
	
	
	@Override
	public UserAccount findUser(String userId) {

		ResultSet rs = null;
		UserAccount found = null;

		try {
			connection = ConnectionFactory.getConnection();
			preparedStatment = connection.prepareStatement(QueryConstants.SELECT_USER_BY_ID);
			preparedStatment.setString(1, userId.toUpperCase());
			rs = preparedStatment.executeQuery();
			if (rs.next()) {
				found = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4), rs.getString(5), rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9),rs.getString(10));
			}

		} catch (SQLException e) {
			System.out.println("SQLException in get() method");
			e.printStackTrace();
		} finally {
			DBUtils.close(rs);
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}
		return found;
	}

	
	@Override
	public void save(UserAccount user) {
System.out.println("enter in save");
		try {
			System.out.println("enter in try");
			connection = ConnectionFactory.getConnection();
			connection.setAutoCommit(false);

			preparedStatment = connection.prepareStatement(QueryConstants.INSERT_USER);

			preparedStatment.setString(1, user.getUserName());
			preparedStatment.setString(2, user.getPassword());
			preparedStatment.setString(3, user.getRole());
			preparedStatment.setString(4, user.getContact());
			preparedStatment.setString(5, user.getAddress());
			preparedStatment.setString(6, user.getCity());
			preparedStatment.setString(7, user.getState());
			preparedStatment.setString(8, user.getPincode());
			preparedStatment.setString(9, user.getEmail());
			preparedStatment.setString(10, user.getBloodgroup());

			// Execute statement.
			int rowsInserted = preparedStatment.executeUpdate();

			if (rowsInserted > 0) {
				System.out.println("A new account was saved successfully!");
				connection.commit();
			}

		} catch (SQLException e) {
			System.out.println("SQLException in save() method");
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback Exception in save() method");
				e1.printStackTrace();
			}
		} finally {
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}

	}
	
	
	


	@Override
	public void update(String userId, UserAccount newUser) {

		try {
			connection = ConnectionFactory.getConnection();
			connection.setAutoCommit(false);

			preparedStatment = connection.prepareStatement(QueryConstants.UPDATE_USER);

			preparedStatment.setString(1, newUser.getUserName());
			preparedStatment.setString(2, newUser.getPassword());
			preparedStatment.setString(3, newUser.getRole());
			preparedStatment.setString(4, newUser.getContact());
			preparedStatment.setString(5, newUser.getAddress());
			preparedStatment.setString(6, newUser.getCity());
			
			preparedStatment.setString(7, newUser.getState());
			preparedStatment.setString(8, newUser.getPincode());
			preparedStatment.setString(9, newUser.getEmail());
			preparedStatment.setString(10,userId);
			

			// Execute statement.
			int rowsUpdated = preparedStatment.executeUpdate();

			if (rowsUpdated > 0) {
				System.out.println("User " + userId + " was updated successfully!");
				connection.commit();
			}

		} catch (SQLException e) {
			System.out.println("SQLException in update() method");
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback Exception in update() method");
				e1.printStackTrace();
			}
		} finally {
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}

	}



	



}
