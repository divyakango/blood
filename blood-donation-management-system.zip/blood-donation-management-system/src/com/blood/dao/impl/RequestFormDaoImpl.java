package com.blood.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.blood.dao1.RequestFormDao;
import com.blood.model.RequestForm;
import com.blood.model.UserAccount;
import com.blood.utils.ConnectionFactory;
import com.blood.utils.DBUtils;
import com.blood.utils.QueryConstants;

public class RequestFormDaoImpl implements RequestFormDao {
	private Connection connection;

	private PreparedStatement preparedStatment;

	public RequestFormDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public void save(RequestForm user) {
		System.out.println("enter in save");
				try {
					System.out.println("enter in try");
					connection = ConnectionFactory.getConnection();
					connection.setAutoCommit(false);

					preparedStatment = connection.prepareStatement(QueryConstants.INSERT_USER2);
                    
					preparedStatment.setString(1, user.getusername());
					preparedStatment.setString(2, user.getPatientname());
					preparedStatment.setString(3, user.getAge());
					preparedStatment.setString(4, user.getContact());
					preparedStatment.setString(5, user.getHospitalname());
					preparedStatment.setString(6, user.getLocation());
					preparedStatment.setString(7, user.getPurpose());
					preparedStatment.setString(8, user.getRequireddate());
					preparedStatment.setString(9, user.getBloodgroup());
					preparedStatment.setString(10, user.getquantity());
					

					// Execute statement.
					int rowsInserted = preparedStatment.executeUpdate();

					if (rowsInserted > 0) {
						System.out.println("A new request was saved successfully!");
						connection.commit();
					}

				} catch (SQLException e) {
					System.out.println("SQLException in save() method");
					e.printStackTrace();
					try {
						connection.rollback();
					} catch (SQLException e1) {
						System.out.println("Rollback Exception in save() method");
						e1.printStackTrace();
					}
				} finally {
					DBUtils.close(preparedStatment);
					DBUtils.close(connection);
				}

			}

	@Override
	
	
	
	public List<RequestForm> allUsers() throws SQLException {

        ResultSet rs = null;
        List<RequestForm> foundList = new ArrayList<RequestForm>();
        RequestForm currentUser = null;
        try {
             connection = ConnectionFactory.getConnection();
             preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER2);
             rs = preparedStatment.executeQuery();
             while (rs.next()) {
                  currentUser = new RequestForm(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10),rs.getString(11));
                  foundList.add(currentUser);
                  System.out.println(currentUser);
                  //System.out.println("123");
             }
        } catch (SQLException e) {
             System.out.println("SQLException in get() method");
             e.printStackTrace();
        } finally {
             DBUtils.close(rs);
             DBUtils.close(preparedStatment);
             DBUtils.close(connection);
        }
        return foundList;
  }
	
	
	
	
@Override
	
	
	
	public List<RequestForm> allUsers1() throws SQLException {

        ResultSet rs = null;
        List<RequestForm> foundList = new ArrayList<RequestForm>();
        RequestForm currentUser = null;
        try {
             connection = ConnectionFactory.getConnection();
             preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER4);
             rs = preparedStatment.executeQuery();
             while (rs.next()) {
                  currentUser = new RequestForm(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10),rs.getString(11));
                  foundList.add(currentUser);
                  System.out.println(currentUser);
                  //System.out.println("123");
             }
            
             
        } catch (SQLException e) {
             System.out.println("SQLException in get() method");
             e.printStackTrace();
        } finally {
             DBUtils.close(rs);
             DBUtils.close(preparedStatment);
             DBUtils.close(connection);
        }
        return foundList;
  }
	



@Override
public void update(String userId, String status) {

	try {
		connection = ConnectionFactory.getConnection();
		connection.setAutoCommit(false);

		preparedStatment = connection.prepareStatement(QueryConstants.UPDATE_USER1);

		preparedStatment.setString(1, userId);
		preparedStatment.setString(2, status);
		
		

		// Execute statement.
		int rowsUpdated = preparedStatment.executeUpdate();

		if (rowsUpdated > 0) {
			System.out.println("User " + userId + " was updated successfully!");
			connection.commit();
		}

	} catch (SQLException e) {
		System.out.println("SQLException in update() method");
		e.printStackTrace();
		try {
			connection.rollback();
		} catch (SQLException e1) {
			System.out.println("Rollback Exception in update() method");
			e1.printStackTrace();
		}
	} finally {
		DBUtils.close(preparedStatment);
		DBUtils.close(connection);
	}

}


















public List<RequestForm> allUsers2() throws SQLException {

    ResultSet rs = null;
    List<RequestForm> foundList = new ArrayList<RequestForm>();
    RequestForm currentUser = new RequestForm();
    
    
   

    try {
         connection = ConnectionFactory.getConnection();
         preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER6);
     	preparedStatment.setString(1, currentUser.getusername());
     	System.out.println(currentUser.getusername());
         rs = preparedStatment.executeQuery();
         
         
         while (rs.next()) {
              currentUser = new RequestForm(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10),rs.getString(11));
              foundList.add(currentUser);
              System.out.println(currentUser);
              //System.out.println("123");
         }
    } catch (SQLException e) {
         System.out.println("SQLException in get() method");
         e.printStackTrace();
    } finally {
         DBUtils.close(rs);
         DBUtils.close(preparedStatment);
         DBUtils.close(connection);
    }
    return foundList;
}








@Override
public void acceptAppointment(String username,String patientname,String contact) {
       try {
        connection = ConnectionFactory.getConnection();
    //    connection.setAutoCommit(false);

        String sql = "update xbbnhnj_request_form set status='Accepted' where username=? and patientname=? and contact=?";

        PreparedStatement pstm = connection.prepareStatement(sql);
        pstm.setString(1, username);
        pstm.setString(2, patientname);
        pstm.setString(3, contact);
        pstm.executeUpdate();
} catch (SQLException e) {
        System.out.println("SQLException in get() method");
        e.printStackTrace();
} finally {
        DBUtils.close(preparedStatment);
        DBUtils.close(connection);
}

}



@Override
public void declineAppointment(String username,String patientname,String contact) {
       // TODO Auto-generated method stub
       try {
        connection = ConnectionFactory.getConnection();
    //    connection.setAutoCommit(false);

        String sql = "update xbbnhnj_request_form set status='Declined' where username=? and patientname=? and contact=?";

        PreparedStatement pstm = connection.prepareStatement(sql);
        
        pstm.setString(1, username);
        pstm.setString(2, patientname);
        pstm.setString(3, contact);
        pstm.executeUpdate();
} catch (SQLException e) {
        System.out.println("SQLException in get() method");
        e.printStackTrace();
} finally {
        DBUtils.close(preparedStatment);
        DBUtils.close(connection);
}
}




/*public List<RequestForm> queryAppointment11(String user){
              
              ResultSet rs = null;
              List<RequestForm> list = new ArrayList<RequestForm>();
              RequestForm docapp = null;
              try {
                     connection = ConnectionFactory.getConnection();

              String sql = "Select a.registerUsername,a.dateOfAppointment,a.status from XBBNHMX_APPOINTMENT a join XBBNHMX_USER b on a.registerUsername=b.userName where a.doctorName=? and b.role='patient'";

              PreparedStatement pstm = connection.prepareStatement(sql);
       pstm.setString(1, user);

       rs = pstm.executeQuery();
       
              while (rs.next()) {
                     
                     String date = rs.getString("dateOfAppointment");
                     String userName = rs.getString("registerUsername");
                     String status = rs.getString("status");
                     
                     docapp=new Appointment();
              
                     docapp.setDateOfAppointment(date);
                     docapp.setUserName(userName);
                     docapp.setStatus(status);
                     list.add(docapp);
              }
              } catch (SQLException e) {
                     System.out.println("SQLException in get() method");
                     e.printStackTrace();
              } finally {
                     DbUtil.close(rs);
                     DbUtil.close(preparedStatment);
                     DbUtil.close(connection);
              }
              return list;
       }
*/








	
}
