package com.blood.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import java.util.ArrayList;
import java.util.List;

import com.blood.dao1.DonorFormDao;
import com.blood.model.DonorForm;
import com.blood.utils.ConnectionFactory;
import com.blood.utils.DBUtils;
import com.blood.utils.QueryConstants;

public class DonorFormDaoImpl implements DonorFormDao {
	
	private Connection connection;

	private PreparedStatement preparedStatment;
	public DonorFormDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	public void save(DonorForm user) {
System.out.println("enter in save");
		try {
			System.out.println("enter in try");
			connection = ConnectionFactory.getConnection();
			connection.setAutoCommit(false);

			preparedStatment = connection.prepareStatement(QueryConstants.INSERT_USER1);
            
			preparedStatment.setString(1, user.getUsername());
			preparedStatment.setString(2, user.getContact());
			preparedStatment.setString(3, user.getLocation());
			preparedStatment.setString(4, user.getDonationdate());
			preparedStatment.setString(5, user.getBloodgroup());
			preparedStatment.setString(6, user.getQuantity());
			

			// Execute statement.
			int rowsInserted = preparedStatment.executeUpdate();

			if (rowsInserted > 0) {
				System.out.println("A new request was saved successfully!");
				connection.commit();
			}

		} catch (SQLException e) {
			System.out.println("SQLException in save() method");
			e.printStackTrace();
			try {
				connection.rollback();
			} catch (SQLException e1) {
				System.out.println("Rollback Exception in save() method");
				e1.printStackTrace();
			}
		} finally {
			DBUtils.close(preparedStatment);
			DBUtils.close(connection);
		}

	}
	
	
	
	/*public List<DonorForm> allUsers() throws SQLException {

        ResultSet rs = null;
        List<DonorForm> foundList = new ArrayList<DonorForm>();
        DonorForm currentUser = null;
        try {
        	System.out.println("enter in try");
             connection = ConnectionFactory.getConnection();
             preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER1);
             rs = preparedStatment.executeQuery();
             while (rs.next()) {
            	 System.out.println("eneter in while");
                  currentUser = new DonorForm(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
                  foundList.add(currentUser);
                  System.out.println(currentUser);
                  //System.out.println("123");
             }
        } catch (SQLException e) {
             System.out.println("SQLException in get() method");
             e.printStackTrace();
        } finally {
             DBUtils.close(rs);
             DBUtils.close(preparedStatment);
             DBUtils.close(connection);
        }
        return foundList;
  }*/
	
	
	
	
	public List<DonorForm> allUsers() throws SQLException {

        ResultSet rs = null;
        List<DonorForm> foundList = new ArrayList<DonorForm>();
        DonorForm currentUser = null;
        try {
             connection = ConnectionFactory.getConnection();
             preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER1);
             rs = preparedStatment.executeQuery();
             while (rs.next()) {
                  currentUser = new DonorForm(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6));
                  foundList.add(currentUser);
                  System.out.println(currentUser);
                  //System.out.println("123");
             }
        } catch (SQLException e) {
             System.out.println("SQLException in get() method");
             e.printStackTrace();
        } finally {
             DBUtils.close(rs);
             DBUtils.close(preparedStatment);
             DBUtils.close(connection);
        }
        return foundList;
  }

}
