package com.blood.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.blood.dao1.DonationCampDao;
import com.blood.model.DonationCamp;
import com.blood.utils.ConnectionFactory;
import com.blood.utils.DBUtils;
import com.blood.utils.QueryConstants;

public class DonationCampDaoImpl implements DonationCampDao {
	private Connection connection;

	private PreparedStatement preparedStatment;

	public DonationCampDaoImpl() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	
	
	
	public List<DonationCamp> allUsers() throws SQLException {

        ResultSet rs = null;
        List<DonationCamp> foundList = new ArrayList<DonationCamp>();
        DonationCamp currentUser = null;
        try {
             connection = ConnectionFactory.getConnection();
             preparedStatment = connection.prepareStatement(QueryConstants.SELECT_ALL_USER3);
             rs = preparedStatment.executeQuery();
             while (rs.next()) {
                  currentUser = new DonationCamp(rs.getString(1), rs.getString(2), rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7), rs.getString(8));
                  foundList.add(currentUser);
                  System.out.println(currentUser);
                  //System.out.println("123");
             }
        } catch (SQLException e) {
             System.out.println("SQLException in get() method");
             e.printStackTrace();
        } finally {
             DBUtils.close(rs);
             DBUtils.close(preparedStatment);
             DBUtils.close(connection);
        }
        return foundList;
  }
			
}
