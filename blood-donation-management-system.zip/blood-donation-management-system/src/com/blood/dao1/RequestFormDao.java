package com.blood.dao1;


import java.sql.SQLException;
import java.util.List;




import com.blood.model.RequestForm;
import com.blood.model.UserAccount;

public interface RequestFormDao {
	
	void save(RequestForm user);
	List<RequestForm> allUsers() throws SQLException;

	List<RequestForm> allUsers1() throws SQLException;

	List<RequestForm> allUsers2() throws SQLException;
	
	void update(String userId, String status);
	
	
	
	/*List<RequestForm> queryAppointment(String user);*/

	void declineAppointment(String username, String patientname,String contact);

	       void acceptAppointment(String username, String patientname, String contact);

	
	}

