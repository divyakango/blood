package com.blood.dao1;

import java.sql.SQLException;
import java.util.List;

import com.blood.model.DonorForm;



public interface DonorFormDao {
	void save(DonorForm user);
	List<DonorForm> allUsers() throws SQLException;
	
}
