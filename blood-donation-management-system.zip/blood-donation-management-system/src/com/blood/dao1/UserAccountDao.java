package com.blood.dao1;

import java.sql.SQLException;
import java.util.List;

import com.blood.model.UserAccount;

public interface UserAccountDao {
	
	void save(UserAccount user);
	
	UserAccount findUser(String userId, String userPass);


	List<UserAccount> allUsers() throws SQLException;
	UserAccount findUser(String userId);
	void update(String userId, UserAccount newUSer);


}
