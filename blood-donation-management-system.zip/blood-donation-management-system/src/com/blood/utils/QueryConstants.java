package com.blood.utils;

public class QueryConstants {
public static final String INSERT_USER = "INSERT INTO XBBNHNJ_Login VALUES(?,?,?,?,?,?,?,?,?,?)";
	public static final String UPDATE_USER = "UPDATE XBBNHNJ_Login SET username=?,PASSWORD=?,ROLE=?,contact=?,address=?,city=?,state=?,pincode=?,email=? WHERE  username=?";
	public static final String UPDATE_USER1 = "UPDATE XBBNHNJ_Request_Form SET status=? where username=?";
	//public static final String DELETE_USER= "DELETE FROM GD_LOGIN WHERE LOGIN_ID=?";
	public static final String SELECT_USER = "SELECT * FROM XBBNHNJ_Login WHERE username=? AND password=?";
	public static final String SELECT_USER_BY_ID = "SELECT * FROM XBBNHNJ_Login WHERE username=?";
	public static final String SELECT_ALL_USER = "SELECT username,password,role,contact,address,city,state,pincode,email,bloodgroup FROM XBBNHNJ_Login";
	public static final String SELECT_ALL_USER1 = "SELECT * FROM XBBNHNJ_Donation_Form";
	public static final String SELECT_ALL_USER2 = "SELECT * FROM XBBNHNJ_Request_Form";
	public static final String SELECT_ALL_USER6 = "SELECT * FROM XBBNHNJ_Request_Form where username=?";
	public static final String SELECT_ALL_USER4 = "SELECT * FROM XBBNHNJ_Request_Form where status='Pending'";
	public static final String SELECT_ALL_USER5 = "SELECT * FROM XBBNHNJ_Request_Form where status='Pending' AND username=?";
	public static final String SELECT_ALL_USER3 = "SELECT * FROM XBBNHNJ_Donation_Camp";
	
	public static final String INSERT_USER1 = "INSERT INTO XBBNHNJ_Donation_Form VALUES(?,?,?,?,?,?)";
	public static final String INSERT_USER2 = "INSERT INTO XBBNHNJ_Request_Form(username,patientname,age,contact,hospitalname,location,purpose,requireddate,bloodgroup,quantity) VALUES(?,?,?,?,?,?,?,?,?,?)";
}


//SELECT * FROM GD_ACCOUNT;
//
//DROP TABLE GD_LOGIN;
//CREATE TABLE GD_LOGIN
//(
//  LOGIN_ID VARCHAR(200),
//  PASSWORD VARCHAR(200),
//  ROLE VARCHAR2(20)
//);
//
//INSERT INTO GD_LOGIN VALUES('N001','123','normal');
//INSERT INTO GD_LOGIN VALUES('N002','123','normal');
//INSERT INTO GD_LOGIN VALUES('N003','123','normal');
//INSERT INTO GD_LOGIN VALUES('N004','123','normal');
//INSERT INTO GD_LOGIN VALUES('N005','123','normal');
//
//INSERT INTO GD_LOGIN VALUES('A001','123','admin');
//INSERT INTO GD_LOGIN VALUES('A002','123','admin');
//INSERT INTO GD_LOGIN VALUES('A003','123','admin');
//INSERT INTO GD_LOGIN VALUES('A004','123','admin');
//INSERT INTO GD_LOGIN VALUES('A005','123','admin');
//
//COMMIT;
//SELECT * FROM GD_Login;


