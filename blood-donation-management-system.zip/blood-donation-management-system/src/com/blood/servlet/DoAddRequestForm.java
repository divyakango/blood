package com.blood.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.blood.dao.impl.RequestFormDaoImpl;
import com.blood.model.RequestForm;


@WebServlet(urlPatterns = { "/DoAddRequestForm" })
public class DoAddRequestForm extends HttpServlet {

	
	private static final long serialVersionUID = 4359681884097568066L;
	private RequestFormDaoImpl userDao = new RequestFormDaoImpl();

	public DoAddRequestForm() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String username = (String) request.getParameter("username");
		String patientname = (String) request.getParameter("patientname");
		String age = (String) request.getParameter("age");
		String contact = (String) request.getParameter("contact");
		String hospitalname = (String) request.getParameter("hospitalname");
		String location = (String) request.getParameter("location");
		String purpose = (String) request.getParameter("purpose");
		String requireddate = (String) request.getParameter("requireddate");
		String bloodtype = (String) request.getParameter("bloodtype");
		String numberofunits = (String) request.getParameter("numberofunits");
		String status = (String) request.getParameter("status");
		

		System.out.println(username+" "+ patientname+" "+ age+" "+ contact+" "+ hospitalname+" "+ location+" "+ purpose+" "+ requireddate+" "+ bloodtype+" "+numberofunits+" "+ status);
		
		RequestForm newUser = new RequestForm(username,patientname,age,contact,hospitalname,location,purpose,requireddate,bloodtype,numberofunits,status);
		String errorString = null;

		

		if (requireddate == null) {
			errorString = "	This field is required";
		}

		if (errorString == null) {
			userDao.save(newUser);
			
			
			
			HttpSession session = request.getSession();
			session.setAttribute("user", username);
			
			
			System.out.println(username);
			
		}

		// Store infomation to request attribute, before forward to views.
		request.setAttribute("errorString", errorString);
		request.setAttribute("newUser", newUser);

		// If error, forward to Edit page.
		if (errorString != null) {
			RequestDispatcher dispatcher = request.getServletContext()
					.getRequestDispatcher("/requestform.jsp");
			dispatcher.forward(request, response);
		}

		// If everything nice.
		// Redirect to the product listing page.
		else {
			response.sendRedirect(request.getContextPath() + "/viewHospitalProfile.jsp");
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}