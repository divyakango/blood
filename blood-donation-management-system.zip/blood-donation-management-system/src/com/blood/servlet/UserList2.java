package com.blood.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.blood.dao.impl.RequestFormDaoImpl;
import com.blood.dao1.RequestFormDao;
import com.blood.model.RequestForm;





@WebServlet("/userList2")
public class UserList2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RequestFormDao userDao = new RequestFormDaoImpl();

	public UserList2() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		String errorString = null;
		List<RequestForm> allUsers = null;
		try {
			allUsers = userDao.allUsers();
			
			System.out.println(allUsers);

		} catch (SQLException e) {
			e.printStackTrace();
			errorString = e.getMessage();
		}
		//System.out.println(allUsers);

		// Store info in request attribute, before forward to views
		request.setAttribute("errorString", errorString);
		session.setAttribute("userList2", allUsers);
		System.out.println("-------------");
		System.out.println(allUsers);
		System.out.println("---------");
		
		// Forward to /WEB-INF/views/productListView.jsp
		RequestDispatcher dispatcher = request.getServletContext()
				.getRequestDispatcher("/RequestDetails.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
