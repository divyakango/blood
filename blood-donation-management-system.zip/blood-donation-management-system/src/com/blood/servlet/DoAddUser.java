package com.blood.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;









import javax.servlet.http.HttpSession;

import com.blood.dao.impl.UserAccountDaoImpl;
import com.blood.dao1.UserAccountDao;
import com.blood.model.UserAccount;
import com.blood.utils.ConnectionFactory;
import com.blood.utils.DBUtils;

@WebServlet(urlPatterns = { "/doAddUser" })
public class DoAddUser extends HttpServlet {
	private Connection connection;
	private Statement statement;
	private PreparedStatement preparedStatment;
	
	private static final long serialVersionUID = 4359681884097568066L;
	private UserAccountDao userDao = new UserAccountDaoImpl();

	public DoAddUser() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String loginId = (String) request.getParameter("username");
		String passowrd = (String) request.getParameter("password");
		String role = (String) request.getParameter("role");
		String contact = (String) request.getParameter("contact");
		String address = (String) request.getParameter("address");
		String city = (String) request.getParameter("city");
		String state = (String) request.getParameter("state");
		String pincode = (String) request.getParameter("pincode");
		String email = (String) request.getParameter("email");
		String bloodgroup = (String) request.getParameter("bloodgroup");

		System.out.println(loginId+" "+ passowrd+" "+ role+" "+contact+" "+address+" "+city+" "+state+" "+pincode+" "+email+" "+bloodgroup);
		
		UserAccount newUser = new UserAccount(loginId, passowrd, role,contact,address,city,state,pincode,email,bloodgroup);
		String errorString = null;

		String regex = "^[a-zA-Z][0-9]{3}$";
		
		
		
		
		String a=null;
		ResultSet rs=null;

        HttpSession session = request.getSession();
        
        try {
               connection = ConnectionFactory.getConnection();
               preparedStatment = connection.prepareStatement("select * from xbbnhnj_login where username=? ");
               preparedStatment.setString(1, loginId);
        
               rs = preparedStatment.executeQuery();
 
               if (rs.next())
               {                  
                     System.out.println("user already exist");            
                     a="user already exists";             
               }
               else
               {  
              
               System.out.println("new user");   
               a="";
               }
               
               session.setAttribute("j", a);

        }
        catch (SQLException e) 
        {
               System.out.println("SQLException in get() method");
               e.printStackTrace();
        }
        finally 
        {
               DBUtils.close(rs);
               DBUtils.close(preparedStatment);
               DBUtils.close(connection);
        }
        
		
        if ( !loginId.matches(regex)) {
			System.out.println("enter");
			errorString = "Username is not in the Form of ^[a-zA-Z][0-9]{3}$ !";
		}
		

		if (errorString == null) {
			userDao.save(newUser);
			//errorString="Registered";
		}

		
		
		
		
		
		// Store infomation to request attribute, before forward to views.
		
		request.setAttribute("newUser", newUser);

		// If error, forward to Edit page.
		if (errorString ==  null) {
			RequestDispatcher dispatcher = request.getServletContext()
					.getRequestDispatcher("/signup.jsp");
			dispatcher.forward(request, response);
		}

		// If everything nice.
		// Redirect to the product listing page.
		else {
			request.setAttribute("errorString", errorString);
			response.sendRedirect(request.getContextPath() + "/login.jsp");
		}

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}