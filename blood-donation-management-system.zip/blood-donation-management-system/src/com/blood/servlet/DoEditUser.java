package com.blood.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.blood.dao.impl.UserAccountDaoImpl;
import com.blood.dao1.UserAccountDao;
import com.blood.model.UserAccount;

@WebServlet(urlPatterns = { "/doEditUser" })
public class DoEditUser extends HttpServlet {
	private static final long serialVersionUID = 4645721142572801104L;
	private UserAccountDao userDao = new UserAccountDaoImpl();

	public DoEditUser() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String loginId = (String) request.getParameter("username");
		String password = (String) request.getParameter("password");
		String role = (String) request.getParameter("role");
		String contact = (String) request.getParameter("contact");
		String address = (String) request.getParameter("address");

		String city = (String) request.getParameter("city");

		String state = (String) request.getParameter("state");

		String pincode = (String) request.getParameter("pincode");

		String email = (String) request.getParameter("email");
		String bloodgroup = (String) request.getParameter("bloodgroup");


		UserAccount editUser = new UserAccount(loginId, password, role,contact,address,city,state,pincode,email,bloodgroup);
		System.out.println("----------------");
		System.out.println(editUser);
		System.out.println("----------------");
		userDao.update(loginId, editUser);
		HttpSession session = request.getSession(true);

		
		if(editUser.getRole().equals("donor"))
		{
			response.sendRedirect(request.getContextPath() + "/ViewDonorProfile.jsp");
			
			
		}
		else 		if(editUser.getRole().equals("hospital"))
		{
			
			response.sendRedirect(request.getContextPath() + "/viewHospitalProfile.jsp");
			
		}
		else
		{
			response.sendRedirect(request.getContextPath() + "/viewBbProfile.jsp");
			
			
		}
		
		

	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}

