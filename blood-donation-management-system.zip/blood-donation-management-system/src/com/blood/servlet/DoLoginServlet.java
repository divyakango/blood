package com.blood.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.blood.dao.impl.UserAccountDaoImpl;
import com.blood.dao1.UserAccountDao;
import com.blood.model.UserAccount;

@WebServlet("/validate")
public class DoLoginServlet extends HttpServlet {


	private static final long serialVersionUID = 5590990410746775329L;
	private UserAccountDao userDao = new UserAccountDaoImpl();

	public DoLoginServlet() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
System.out.println(userName + password);
		UserAccount user = null;
		boolean hasError = false;
		String errorString = null;

		if (userName == null || password == null || userName.length() == 0 || password.length() == 0) {
			hasError = true;
			errorString = "Required username and password!";
			System.out.println(errorString);
		} else {

			user = userDao.findUser(userName, password);
			if (user == null) {
				hasError = true;
				errorString = "User Name or password invalid";
				System.out.println(errorString);	}

		}
		// If error, forward to /WEB-INF/views/_login.jsp
		if (hasError) {
			user = new UserAccount();
			user.setUserName(userName);
			user.setPassword(password);

			// Store information in request attribute, before forward.
			request.setAttribute("errorString", errorString);
			request.setAttribute("user", user);
			

			// Forward to /WEB-INF/views/_login.jsp
			getServletContext().getRequestDispatcher("/login.jsp").forward(request, response);
		}

		// If no error
		// Store user information in Session
		// And redirect to correct home page.
		else {
			HttpSession session = request.getSession(true);
			session.setAttribute("userIs", user);
			session.setAttribute("username", user.getUserName());
			if (user.getRole().equals("donor")) {
				// Redirect to userInfo page.
				
				
				
				try{
					session.setAttribute("username",userName);
					UserAccountDao Emp=new UserAccountDaoImpl();
			
					UserAccount checkDetail= ((UserAccountDaoImpl) Emp).getDetail(userName);
					
//					request.setAttribute("checkDetail",checkDetail);
					  session.setAttribute("checkDetail",checkDetail); 
					  


					}
					catch(SQLException e)
					{System.out.println(e.getMessage());}
				getServletContext().getRequestDispatcher("/ViewDonorProfile.jsp").forward(request, response);
			} 
			else if (user.getRole().equals("hospital")) {
				try{
					HttpSession session1 = request.getSession(true);
					UserAccountDao Emp=new UserAccountDaoImpl();
			session1.setAttribute("username",user.getUserName() );
			session1.setAttribute("bloodgroup", user.getBloodgroup());
			
					UserAccount checkDetail= ((UserAccountDaoImpl) Emp).getDetail(userName);
					
//					request.setAttribute("checkDetail",checkDetail);
					  session.setAttribute("checkDetail",checkDetail); 
					  


					}
					catch(SQLException e)
					{System.out.println(e.getMessage());}
				// Redirect to userInfo page.
				getServletContext().getRequestDispatcher("/viewHospitalProfile.jsp").forward(request, response);
			} 
			else if (user.getRole().equals("bloodbank")) {
				
				try{
					UserAccountDao Emp=new UserAccountDaoImpl();
			
					UserAccount checkDetail= ((UserAccountDaoImpl) Emp).getDetail(userName);
					
//					request.setAttribute("checkDetail",checkDetail);
					  session.setAttribute("checkDetail",checkDetail); 
					  


					}
					catch(SQLException e)
					{System.out.println(e.getMessage());}
				// Redirect to userInfo page.
				getServletContext().getRequestDispatcher("/viewBbProfile.jsp").forward(request, response);
			} 
			
			else
				// Redirect to userInfo page.
				getServletContext().getRequestDispatcher("/adminafterlogin.jsp").forward(request, response);
			
		}
		
		/*else {
            HttpSession session = request.getSession();
            MyUtils.storeLoginedUser(session, user1);
            System.out.println(user1.getRole());
            if (user1.getRole().equals("admin")) {
            
                            getServletContext().getRequestDispatcher("/AdminHome.jsp").forward(request, response);
            } else if(user1.getRole().equals("student"))
                            getServletContext().getRequestDispatcher("/studentHome.jsp").forward(request, response);
            else
                            getServletContext().getRequestDispatcher("/TeacherHome.jsp").forward(request, response);
            
}*/

	
		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}





/*package com.carparking.servlet;
 * 

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.carparking.dao1.UserAccountDao;
import com.carparking.dao.implementation.UserAccountDaoImplementation;
import com.carparking.model.UserAccount;

@WebServlet("/dologin")
public class DoLoginServlet extends HttpServlet {

	*//**
	 * 
	 *//*
	private static final long serialVersionUID = 491357214476002160L;

	public DoLoginServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		
		String user = request.getParameter("userName");
		String pass = request.getParameter("password");
		String role = request.getParameter("role");
		UserAccountDao empDao = new UserAccountDaoImplementation();
		
		try {
			UserAccount regEmp = empDao.get(user);
			
			if(regEmp != null){
				System.out.println(regEmp.getPassword());
				
				if (regEmp.getPassword().equals(pass)){
					System.out.println("dsadsa");
					HttpSession sessionEmp = request.getSession(true);
					sessionEmp.setAttribute("userId", regEmp.getUserName());
					getServletContext().getRequestDispatcher(
							"/WEB-INF/views/index11.jsp").forward(request,
							response);
				}
			}
			else {
				String msg = "Incorrect Password";
				System.out.println(msg);
				request.setAttribute("passError", msg);
				getServletContext().getRequestDispatcher(
						"/WEB-INF/views/index.jsp").forward(request,
						response);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			String msg = "Incorrect Id or Password";
			System.out.println(msg);
			request.setAttribute("IdError", msg);
			getServletContext().getRequestDispatcher(
					"/WEB-INF/views/index.jsp").forward(request,
					response);


		}

	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
*/