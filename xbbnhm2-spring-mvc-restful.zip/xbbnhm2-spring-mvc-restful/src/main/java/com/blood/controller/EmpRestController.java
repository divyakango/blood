package com.blood.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.blood.dao.EmpDaoImpl;
import com.blood.model.Emp;
import com.blood.model.UserAccount;

@RestController
public class EmpRestController {
@Autowired
     private EmpDaoImpl empDaoImpl;

     @GetMapping("/employees")
     public List<UserAccount> getAllEmployees() {
           return empDaoImpl.getAllEmployees();
     }

     @GetMapping("/employees/{username}")
     public ResponseEntity<Object> getEmployee(@PathVariable("username") String username) {
          UserAccount emp = empDaoImpl.getEmployeeById(username);
           if (emp == null) {
                return new ResponseEntity<Object>("No Employee found for ID " + username, HttpStatus.NOT_FOUND);
           } 
           return new ResponseEntity<Object>(emp, HttpStatus.OK);
     }
     
    /* @PostMapping(value = "/employees")
     public ResponseEntity<Object> insertEmployee(@RequestBody Emp emp) {
           empDaoImpl.save(emp);
           return new ResponseEntity<Object>(emp, HttpStatus.OK);
     }
     
     @DeleteMapping("/employees/{id}")
     public ResponseEntity<Object> deleteEmployee(@PathVariable int id) {
           empDaoImpl.delete(id);
           return new ResponseEntity<Object>("Employee deleted with ID " + id, HttpStatus.OK);
     }

     @PutMapping("/employees/{id}")
     public ResponseEntity<Object> updateEmployee(@PathVariable int id, @RequestBody Emp emp) {
           empDaoImpl.update(id, emp);
           return new ResponseEntity<Object>("Employee udpated with ID " + id, HttpStatus.OK);
     }*/
}




