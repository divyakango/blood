package com.blood.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.blood.dao.RequestDao;
import com.blood.model.RequestForm;

@RestController
public class HospitalController {
	
	@Autowired
	RequestDao requestDao;
	
	@RequestMapping(value="/approve/{contact}",method=RequestMethod.GET)
    public void approveRequest(@PathVariable String contact){

          requestDao.update(contact);          
   
    }
	
	@RequestMapping(value="/viewRequests",method=RequestMethod.GET)
    public List<RequestForm> view(){
          
          List<RequestForm> requests=requestDao.viewDetails();
          
          return requests;
    }


}
