package com.blood.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.blood.model.RequestForm;
import com.blood.util.HospRowMapper;

public class RequestDao {

	private JdbcTemplate template;

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	
	public void update(String contact) {
		String query = "UPDATE XBBNHNJ_Request_Form SET status='approved' WHERE contact="+contact;
		template.update(query);

	}

	public List<RequestForm> viewDetails() {
		List<RequestForm> request = null;
		String query = "select * from XBBNHNJ_Request_Form where status='Pending'";
		//System.out.println(query);
		request = template.query(query, new HospRowMapper());
		return request;
	}
}
