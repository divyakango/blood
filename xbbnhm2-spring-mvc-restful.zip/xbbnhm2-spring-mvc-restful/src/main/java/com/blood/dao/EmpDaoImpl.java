package com.blood.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.blood.model.Emp;
import com.blood.model.UserAccount;
import com.blood.util.EmpRowMapper;

public class EmpDaoImpl {

	private JdbcTemplate template;

	public EmpDaoImpl() {
		super();

	}

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	/*public int save(Emp e) {
		String query = "INSERT INTO EMP99 VALUES(" + e.getId() + ",'"
				+ e.getName() + "','" + e.getSalary() + "','"
				+ e.getDesignation() + "')";
		System.out.println(query);
		return template.update(query);
	}

	public int update(int searchById, Emp newEmp) {
		String query = "UPDATE EMP99 SET ID=" + newEmp.getId() + " ,NAME='"
				+ newEmp.getName() + "',SALARY='" + newEmp.getSalary()
				+ "',DESIGNATION='" + newEmp.getDesignation() + "' WHERE ID="
				+ searchById;

		System.out.println(query);
		return template.update(query);

	}

	public int delete(int searchById) {

		String query = "DELETE FROM EMP99 WHERE ID=" + searchById;

		System.out.println(query);
		return template.update(query);

	}*/

	public UserAccount getEmployeeById(String searchByusername) {

		UserAccount foundEmployees = null;

		String query = "SELECT * FROM XBBNHNJ_Login WHERE username='" + searchByusername+"'";

		System.out.println(query);
		foundEmployees = template.queryForObject(query, new EmpRowMapper());
		/*
		 * foundEmployees=template.queryForObject(query,new
		 * Object[]{searchById},new EmpRowMapper());
		 */
		return foundEmployees;

	}

	public List<UserAccount> getAllEmployees() {

		List<UserAccount> allEmployees = null;
		String query = "select * from XBBNHNJ_Login";
		System.out.println(query);
		allEmployees = template.query(query, new EmpRowMapper());
		return allEmployees;
	}

}
