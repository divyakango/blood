package com.blood.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.blood.model.Emp;
import com.blood.model.UserAccount;

public class EmpRowMapper implements RowMapper<UserAccount> {

	@Override
	public UserAccount mapRow(ResultSet rs, int rowNum) throws SQLException {
		/*Emp tempEmp = new Emp(rs.getInt(1), rs.getString(2), rs.getFloat(3),
				rs.getString(4));*/
		UserAccount tempEmp = new UserAccount(rs.getString(1), rs.getString(2), rs.getString(3),
				rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10));

	
	

		/*
		 * tempEmp.setId(rs.getInt(1));
		 * 
		 * tempEmp.setName(rs.getString(2));
		 * 
		 * tempEmp.setSalary(rs.getFloat(3));
		 * 
		 * tempEmp.setDesignation(rs.getString(4)); -
		 */

		return tempEmp;

	}

}
